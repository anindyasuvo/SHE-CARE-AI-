# 🎨 SheCare AI - Visual Design Guide

## 🌈 Visual Identity

```
 ██████╗██╗  ██╗███████╗ ██████╗ █████╗ ██████╗ ███████╗     █████╗ ██╗
██╔════╝██║  ██║██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝    ██╔══██╗██║
███████╗███████║█████╗  ██║     ███████║██████╔╝█████╗      ███████║██║
╚════██║██╔══██║██╔══╝  ██║     ██╔══██║██╔══██╗██╔══╝      ██╔══██║██║
██████╔╝██║  ██║███████╗╚██████╗██║  ██║██║  ██║███████╗    ██║  ██║██║
╚═════╝ ╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝    ╚═╝  ╚═╝╚═╝
                                                                          
           Empowering Women's Health with AI & Empathy 💖
```

---

## 📱 Screen Previews (ASCII Representation)

### Splash Screen
```
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║                                                            ║
║                     ╭──────────╮                          ║
║                    │  ◉  ◉  ◉  │                          ║
║                    │            │                          ║
║                    │   💗  ✨   │  ← Animated Orb         ║
║                    │            │                          ║
║                     ╰──────────╯                          ║
║                                                            ║
║                    SheCare AI                              ║
║              Empowering Women's Health                     ║
║                                                            ║
║              🏥   🍎   👩                                  ║
║           Floating Health Icons                            ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

### Onboarding Slide
```
╔════════════════════════════════════════════════════════════╗
║  Skip →                                                    ║
║                                                            ║
║                     ╭───────────╮                         ║
║                    │             │                         ║
║                    │   💜  💓    │  ← Pulsing Circle      ║
║                    │             │                         ║
║                     ╰───────────╯                         ║
║                                                            ║
║               Understanding Anemia                         ║
║                                                            ║
║    Anemia affects 1 in 3 women worldwide.                 ║
║    It occurs when your blood lacks enough                 ║
║    healthy red blood cells to carry oxygen...             ║
║                                                            ║
║                  ● ● ○ ○                                  ║
║                                                            ║
║       [Previous]              [Next →]                     ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

### Profile Setup
```
╔════════════════════════════════════════════════════════════╗
║  ← Back          Create Your Profile                       ║
║                                                            ║
║                     👤                                     ║
║                  ╭────────╮                               ║
║                 │          │                               ║
║                 │    👧    │  ← Avatar                    ║
║                 │          │                               ║
║                  ╰────────╯                               ║
║                  Welcome!                                  ║
║                                                            ║
║    ╭──────────────────────────────────────────╮          ║
║    │ 👤 │ Full Name                            │          ║
║    ╰──────────────────────────────────────────╯          ║
║                                                            ║
║    ╭──────────────────────────────────────────╮          ║
║    │ 📅 │ Age                                  │          ║
║    ╰──────────────────────────────────────────╯          ║
║                                                            ║
║    ╭──────────────────────────────────────────╮          ║
║    │ 📍 │ Location (City/State)                │          ║
║    ╰──────────────────────────────────────────╯          ║
║                                                            ║
║    [🇬🇧 English] [🇮🇳 हिंदी] [🇮🇳 தமிழ்]                ║
║                                                            ║
║    ╭────────────────────────────────────────────╮        ║
║    │  ⓘ This is not a medical diagnosis...     │        ║
║    ╰────────────────────────────────────────────╯        ║
║                                                            ║
║         [Continue to Assessment →]                         ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

### Questionnaire (Step 2 - Fatigue)
```
╔════════════════════════════════════════════════════════════╗
║  ← Back          Health Assessment                         ║
║                                                            ║
║    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░░  Progress: 2/7       ║
║                                                            ║
║                     ╭──────╮                              ║
║                    │   😫   │  ← Icon                     ║
║                     ╰──────╯                              ║
║                                                            ║
║         How often do you feel tired?                      ║
║            On a scale of 1 to 10                          ║
║                                                            ║
║    Rarely ├─────────●─────────┤ Always                   ║
║     (1)          [7]            (10)                      ║
║                                                            ║
║    ╭──────╮   ╭──────╮   ╭──────╮                        ║
║    │● Low │   │ Med  │   │ High │                        ║
║    ╰──────╯   ╰──────╯   ╰──────╯                        ║
║                                                            ║
║    [← Previous]             [Next →]                      ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

### AI Analysis Loading
```
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║                                                            ║
║                     ╭───────────╮                         ║
║                   ╱│             │╲                        ║
║                  │ │   ╭─────╮   │ │                      ║
║                  │ │  │  ●●  │  │ │  ← Pulsing          ║
║                  │ │   ╰─────╯   │ │     3D Orb          ║
║                   ╲│             │╱                        ║
║                     ╰───────────╯                         ║
║               ◯                     ◯  ← Expanding        ║
║                                           Rings           ║
║         Analyzing Your Health Data                        ║
║      Our AI is processing your responses...               ║
║                                                            ║
║    ✓  Processing health parameters                        ║
║    ✓  Running AI algorithms                               ║
║    ⏳ Calculating risk factors...                         ║
║    ○  Generating recommendations                          ║
║                                                            ║
║    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░  65%                  ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

### Risk Result (Medium Risk)
```
╔════════════════════════════════════════════════════════════╗
║  ← Back          Your Assessment Result         Share 🔗  ║
║                                                            ║
║            Assessment Date: Dec 18, 2024                   ║
║                                                            ║
║                                                            ║
║                     ╭──────────╮                          ║
║                   ╱╱            ╲╲                         ║
║                  ││   ╭──────╮   ││                       ║
║                  ││  │  ⚠️   │  ││  ← Rotating           ║
║                  ││   ╰──────╯   ││     Yellow Orb        ║
║                   ╲╲            ╱╱                         ║
║                     ╰──────────╯                          ║
║                  ※  glowing  ※                            ║
║                                                            ║
║              ╔═══════════════════════╗                    ║
║              ║   MEDIUM RISK ⚠️     ║                    ║
║              ╚═══════════════════════╝                    ║
║                                                            ║
║    Confidence: ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░ 82%                  ║
║                                                            ║
║    Your assessment indicates a medium risk                ║
║    for anemia. Consider consulting a healthcare           ║
║    provider for blood tests...                            ║
║                                                            ║
║    Key Factors: [Vegetarian Diet] [High Fatigue]         ║
║                 [Heavy Flow] [Pale Skin]                  ║
║                                                            ║
║    ⚠️ This is not a medical diagnosis...                 ║
║                                                            ║
║    [View Recommendations →]                                ║
║    [Need Immediate Help?]                                 ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

### Recommendations
```
╔════════════════════════════════════════════════════════════╗
║  ← Back       Your Personalized Plan        Share 🔗      ║
║                                                            ║
║    🍎  Iron-Rich Foods                                    ║
║    ╭──────────────────────────────────────────────────╮  ║
║    │  🥬 Spinach     │  🥩 Red Meat  │  🍗 Chicken    │  ║
║    │  Rich in iron   │  High in heme │  Good protein  │  ║
║    ├─────────────────┼───────────────┼────────────────┤  ║
║    │  🥜 Legumes     │  🥚 Eggs      │  🌰 Nuts       │  ║
║    │  Beans, lentils │  Complete     │  Almonds, seeds│  ║
║    ╰──────────────────────────────────────────────────╯  ║
║                                                            ║
║    💓  Lifestyle Tips                                     ║
║    ╭──────────────────────────────────────────────────╮  ║
║    │ ✅ Pair iron with Vitamin C                       │  ║
║    │    Citrus fruits boost absorption                 │  ║
║    │                                                    │  ║
║    │ ✅ Cook in iron utensils                          │  ║
║    │    Adds small amounts of iron                     │  ║
║    │                                                    │  ║
║    │ ❌ Avoid tea/coffee with meals                    │  ║
║    │    Wait 1-2 hours before/after                    │  ║
║    ╰──────────────────────────────────────────────────╯  ║
║                                                            ║
║    💊  Supplement Guidance                                ║
║    ╭──────────────────────────────────────────────────╮  ║
║    │ 💊  Take on empty stomach for better absorption   │  ║
║    │  ⚠️  Always consult healthcare provider first     │  ║
║    ╰──────────────────────────────────────────────────╯  ║
║                                                            ║
║    [📖 Learn More About Anemia]                           ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

---

## 🎨 Color Palette Visualization

### Primary Colors
```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│              │              │              │              │
│   #FFB3C6    │   #FFE5EC    │   #E0BBE4    │   #D4A5D9    │
│              │              │              │              │
│  Primary     │   Light      │   Primary    │   Light      │
│    Pink      │    Pink      │   Purple     │   Purple     │
│              │              │              │              │
└──────────────┴──────────────┴──────────────┴──────────────┘

┌──────────────┬──────────────┬──────────────┬──────────────┐
│              │              │              │              │
│   #FF6B9D    │   #FFFFFF    │   #2C2C2C    │   #6B6B6B    │
│              │              │              │              │
│   Accent     │    White     │    Text      │    Text      │
│   Coral      │   (BG/Card)  │    Dark      │   Medium     │
│              │              │              │              │
└──────────────┴──────────────┴──────────────┴──────────────┘
```

### Risk Level Colors
```
┌──────────────────┬──────────────────┬──────────────────┐
│                  │                  │                  │
│    #A8E6CF       │    #FFD93D       │    #FF6B9D       │
│                  │                  │                  │
│  ✓ LOW RISK      │  ⚠ MEDIUM RISK   │  ✗ HIGH RISK     │
│    (Green)       │    (Yellow)      │    (Red)         │
│                  │                  │                  │
└──────────────────┴──────────────────┴──────────────────┘
```

---

## 🔤 Typography System

### Font Hierarchy
```
┌───────────────────────────────────────────────────────────┐
│                                                           │
│  SheCare AI                    ← 42px, Nunito 800        │
│                                                           │
│  Understanding Anemia          ← 28px, Nunito 700        │
│                                                           │
│  Your Assessment Result        ← 24px, Nunito 700        │
│                                                           │
│  Iron-Rich Foods               ← 22px, Nunito 700        │
│                                                           │
│  How often do you feel tired?  ← 20px, Nunito 700        │
│                                                           │
│  This is body text with good   ← 16px, Nunito 400        │
│  readability and line height                             │
│                                                           │
│  Small label text              ← 14px, Nunito 600        │
│                                                           │
└───────────────────────────────────────────────────────────┘
```

---

## 🎭 Animation Showcase

### Pulse Animation (Orb)
```
Time:  0s          1s          2s          3s
       ●           ◯           ●           ◯
     scale(1)   scale(1.1)  scale(1)   scale(1.1)
    opacity:1   opacity:0.9 opacity:1  opacity:0.9
```

### Expand Ring Animation
```
Time:  0s          0.5s        1s          1.5s        2s
       ○           ○           ○            ○          ○
     scale(1)   scale(1.2)  scale(1.4)  scale(1.6)  scale(1.8)
    opacity:0.8  opacity:0.6 opacity:0.4 opacity:0.2 opacity:0
```

### Slide Transition
```
State: HIDDEN     →    ENTERING   →   VISIBLE
       ║                 ║              ║
       ║    fadeInSlide  ║              ║
       ║    0.5s ease    ║              ║
       ║                 ║              ║
   opacity: 0        opacity: 0.5   opacity: 1
   Y: +20px          Y: +10px       Y: 0px
```

---

## 📐 Layout Grid System

### Mobile Layout (320-480px)
```
┌─────────────────────────────────────────┐
│ ╔═════════════════════════════════════╗ │
│ ║         Screen Header (60px)        ║ │
│ ╚═════════════════════════════════════╝ │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │                                     │ │
│ │         Content Area                │ │
│ │         (flexible)                  │ │
│ │                                     │ │
│ │  Cards with 16px padding            │ │
│ │  24px gaps between sections         │ │
│ │                                     │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ ╔═════════════════════════════════════╗ │
│ ║      Bottom Navigation (60px)       ║ │
│ ╚═════════════════════════════════════╝ │
└─────────────────────────────────────────┘
    20px        content         20px
   margin                       margin
```

---

## 🎯 Component Library

### Button Styles
```
┌──────────────────────────────────────────────────────┐
│                                                      │
│  ╔════════════════════════════════════════════╗     │
│  ║    Continue to Assessment  →               ║     │  Primary
│  ╚════════════════════════════════════════════╝     │  Large
│   Gradient: Coral → Pink, 18px, Full Width          │
│                                                      │
│  ┌────────────────────────────────────────────┐     │
│  │  Need Immediate Help?  📞                  │     │  Secondary
│  └────────────────────────────────────────────┘     │  Large
│   White BG, Pink Border, 16px                       │
│                                                      │
│  [ Previous ] ← Icon   [ Next → ] Icon              │  Navigation
│   Secondary style, flexible width                   │
│                                                      │
└──────────────────────────────────────────────────────┘
```

### Card Styles
```
┌────────────────────────────────────────────────────┐
│  ╭──────────────────────────────────────────────╮  │  Standard
│  │  🎯 Section Header                           │  │  Card
│  │  ─────────────────────────────────────────   │  │
│  │  Content with good padding (24px)            │  │  24px border
│  │  Clean white background                      │  │  radius
│  │  Soft shadow for depth                       │  │
│  ╰──────────────────────────────────────────────╯  │  Hover: lift
│                                                    │
│  ╭──────────────────────────────────────────────╮  │  Highlight
│  │  ⭐ Special Content                           │  │  Card
│  │  ─────────────────────────────────────────   │  │
│  │  Gradient background (pink-purple)           │  │  Stands out
│  │  Used for important info                     │  │
│  ╰──────────────────────────────────────────────╯  │
│                                                    │
└────────────────────────────────────────────────────┘
```

### Form Elements
```
┌────────────────────────────────────────────────────┐
│  ╭───────────────────────────────────────────╮     │  Floating
│  │ 👤 │ Full Name                            │     │  Label
│  ╰───────────────────────────────────────────╯     │  Input
│        ^ Icon    ^ Animated label                  │
│                                                    │
│  [ Option 1 ]  [ Option 2 ]  [ Option 3 ]         │  Toggle
│     Active       Inactive      Inactive            │  Group
│                                                    │
│  Rarely ├─────────●──────────┤ Always              │  Slider
│   (1)           [7]            (10)                │  Range
│                                                    │
│  ☐ Checkbox Option 1                               │  Checkbox
│  ☑ Checkbox Option 2  ← Checked                    │  List
│  ☐ Checkbox Option 3                               │
│                                                    │
└────────────────────────────────────────────────────┘
```

---

## 🌟 Icon System

### Health Icons (Used Throughout)
```
🏥 Hospital/Medical     💊 Medicine/Pills      🩺 Healthcare
💉 Injection/Test       🧪 Lab/Testing        📋 Clipboard/Form
❤️ Heart/Health        💓 Heartbeat          💗 Love/Care
👩 Woman                🤰 Pregnant           🧑‍⚕️ Doctor
🍎 Nutrition           🥗 Healthy Food       🥬 Vegetables
📱 Mobile              📊 Analytics          📈 Growth
⚠️ Warning             ✓ Success             ✗ Error
🌍 Global              🗣️ Language          🔒 Privacy
```

### UI Icons (Font Awesome)
```
← Back Button          → Next/Continue       📍 Location
👤 User Profile        📅 Calendar/Age       🌐 Language
📖 Education          📞 Phone/Support      🔗 Share
📝 Notes/Text         ✓ Checkmark           ⏳ Loading
```

---

## 📊 Data Visualization

### Progress Bar
```
Step 2 of 7
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░░░  29%
└───────────────────┘
  Completed (gradient fill)
```

### Confidence Meter
```
Confidence: 82%
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░
└─────────┘
   Filled dynamically
```

### Risk Factor Tags
```
┌───────────────┬───────────────┬───────────────┐
│ Vegetarian    │ High Fatigue  │ Heavy Flow    │
│    Diet       │               │               │
└───────────────┴───────────────┴───────────────┘
  Rounded pill-shaped tags with pastel backgrounds
```

---

## 🎬 User Flow Diagram

```
┌─────────────┐
│   SPLASH    │  3s auto
│   SCREEN    │────┐
└─────────────┘    │
                   ↓
┌─────────────┐    ┌─────────────┐
│ ONBOARDING  │←──→│  4 SLIDES   │  Skip option
│   SCREEN    │    │  Swipeable  │
└─────────────┘    └─────────────┘
       │
       ↓
┌─────────────┐
│   PROFILE   │  Name, Age,
│    SETUP    │  Location
└─────────────┘
       │
       ↓
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  QUESTION   │───→│  7 STEPS    │───→│  Progress   │
│    NAIRE    │    │  Validated  │    │   Tracked   │
└─────────────┘    └─────────────┘    └─────────────┘
       │
       ↓
┌─────────────┐
│  ANALYSIS   │  4.5s animation
│   LOADING   │  AI processing
└─────────────┘
       │
       ↓
┌─────────────┐    ┌─────────────┐
│    RISK     │───→│  3D Orb     │
│   RESULT    │    │  Color Code │
└─────────────┘    └─────────────┘
       │
       ├──────────→┌─────────────┐
       │           │ RECOMMEND-  │  Personalized
       │           │   ATIONS    │  Advice
       │           └─────────────┘
       │
       ├──────────→┌─────────────┐
       │           │ EDUCATION   │  Learn about
       │           │     HUB     │  Anemia
       │           └─────────────┘
       │
       └──────────→┌─────────────┐
                   │  EMERGENCY  │  Healthcare
                   │   SUPPORT   │  Resources
                   └─────────────┘
```

---

## 🎨 Design Principles

### 1. Empathy First
```
❤️ Every element designed for women's comfort
🌸 Soft colors that don't alarm
💬 Supportive, encouraging language
🤗 Warm, approachable aesthetics
```

### 2. Clarity & Simplicity
```
📝 One question at a time
🎯 Clear CTAs on every screen
✓ Immediate visual feedback
📊 Progress always visible
```

### 3. Accessibility Always
```
👓 Large, readable text (18px+)
🎨 High contrast ratios (AA compliant)
👆 Big touch targets (44px minimum)
⌨️ Keyboard navigable
📢 Screen reader friendly
```

### 4. Delight in Details
```
✨ Smooth animations (not distracting)
🎭 Micro-interactions on every action
🌈 Gradient transitions
💫 3D effects that impress
```

---

## 📸 Screenshot Checklist

For demo/presentation, capture these screens:

- ✅ Splash screen (animated orb visible)
- ✅ Onboarding slide 3 (AI assessment)
- ✅ Profile setup (filled form)
- ✅ Questionnaire Step 2 (slider mid-position)
- ✅ Questionnaire Step 4 (multiple symptoms checked)
- ✅ Analysis screen (2-3 steps checked)
- ✅ Risk result - Low (green orb)
- ✅ Risk result - Medium (yellow orb)
- ✅ Risk result - High (red orb)
- ✅ Recommendations food grid
- ✅ Education card (symptoms grid visible)
- ✅ Emergency support screen

---

## 🎯 Brand Voice

### Tone Attributes
```
Empathetic    ████████████████████ 100%
Professional  ████████████████░░░░  80%
Friendly      ████████████████████ 100%
Urgent        ██████░░░░░░░░░░░░░░  30%  (only for high risk)
Educational   ████████████████████ 100%
Trustworthy   ████████████████████ 100%
```

### Example Messages
```
✓ Good: "Great news, Priya! Your risk is currently low."
✗ Bad:  "You don't have anemia."

✓ Good: "Consider consulting a healthcare provider..."
✗ Bad:  "You must see a doctor immediately!"

✓ Good: "This is an AI-based assessment, not a diagnosis."
✗ Bad:  "Our AI diagnosed you with..."
```

---

## 💝 Final Design Notes

**Every pixel matters**. From the rounded corners (24px for cards) to the specific pink shade (#FFB3C6), every design decision was made with women's comfort and trust in mind.

**Animations are purposeful**, not decorative. The pulsing orb builds anticipation, the expanding rings suggest processing, and the smooth transitions maintain flow.

**Colors communicate risk** without causing alarm. Green feels safe, yellow suggests caution, red prompts action - but all maintain the soft, approachable aesthetic.

**Typography breathes**. Generous line-height (1.6), ample letter-spacing, and a minimum 16px body text ensure readability for all ages and vision levels.

---

**Built with love ❤️ and attention to every detail**

**Version 1.0.0 | Visual Design System | SIH 2024**
