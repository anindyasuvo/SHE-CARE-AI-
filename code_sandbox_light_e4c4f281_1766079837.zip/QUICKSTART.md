# 🚀 SheCare AI - Quick Start Guide

## ⚡ Get Started in 30 Seconds

### Option 1: Direct Browser Open (Simplest)
```bash
# Just double-click index.html
# Or right-click → Open With → Your Browser
```

### Option 2: Local Server (Recommended)
```bash
# Using Python 3
python -m http.server 8000

# Using Python 2
python -m SimpleHTTPServer 8000

# Using Node.js
npx http-server -p 8000

# Using PHP
php -S localhost:8000
```

Then visit: **http://localhost:8000**

---

## 📱 Mobile Testing

### Desktop Browser (Chrome DevTools)
1. Open the app in Chrome
2. Press `F12` to open DevTools
3. Click the device toggle icon (Ctrl+Shift+M)
4. Select a mobile device (iPhone 12, Pixel 5, etc.)
5. Interact with the app!

### Real Mobile Device
1. Start local server on your computer
2. Find your computer's IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
3. On your phone browser, visit: `http://YOUR_IP:8000`
4. Example: `http://192.168.1.100:8000`

---

## 🎯 Testing Flow

### Complete User Journey (5 minutes)

1. **Splash Screen** (3s) - Auto-advances
   
2. **Onboarding** (4 slides)
   - Click "Next" or "Skip"
   - See educational content
   
3. **Profile Setup**
   - Name: `Priya Sharma`
   - Age: `25`
   - Location: `Mumbai, Maharashtra`
   - Language: Select any
   - Click "Continue to Assessment"
   
4. **Health Questionnaire** (7 steps)
   
   **Step 1 - Diet:**
   - Select: `Vegetarian`
   
   **Step 2 - Fatigue:**
   - Move slider to: `7`
   
   **Step 3 - Dizziness:**
   - Select: `Sometimes`
   
   **Step 4 - Symptoms:**
   - Check: `Hair fall` and `Pale skin`
   
   **Step 5 - Menstrual Health:**
   - Flow: `Heavy`
   - Regularity: `Irregular`
   
   **Step 6 - Pregnancy:**
   - Select: `Neither`
   
   **Step 7 - History:**
   - Select: `No, never diagnosed`
   - Click "Analyze Results"
   
5. **AI Analysis** (4.5s)
   - Watch the beautiful animation
   - See 4 steps complete
   
6. **Risk Result**
   - See color-coded orb (likely Medium/High)
   - Read personalized message
   - Check confidence level
   - Click "View Recommendations"
   
7. **Recommendations**
   - See iron-rich foods
   - Read lifestyle tips
   - Click "Learn More About Anemia"
   
8. **Education Hub**
   - Scroll through all cards
   - Learn about anemia
   - Click "Healthcare Support"
   
9. **Emergency Support**
   - See helpline numbers
   - View government programs
   - Click "Return Home" or use bottom nav

---

## 🧪 Test Scenarios

### Scenario A: Low Risk User
```
Diet: Non-vegetarian
Fatigue: 3
Dizziness: Never
Symptoms: None
Menstrual Flow: Light
Cycle: Regular
Pregnancy: No
Previous Diagnosis: No

Expected Result: Low Risk (Green Orb)
```

### Scenario B: Medium Risk User
```
Diet: Vegetarian
Fatigue: 6
Dizziness: Rarely
Symptoms: Hair fall, Cold hands
Menstrual Flow: Moderate
Cycle: Regular
Pregnancy: No
Previous Diagnosis: No

Expected Result: Medium Risk (Yellow Orb)
```

### Scenario C: High Risk User
```
Diet: Vegan
Fatigue: 9
Dizziness: Frequently
Symptoms: Hair fall, Pale skin, Cold hands, Weak nails
Menstrual Flow: Heavy
Cycle: Irregular
Pregnancy: Pregnant
Previous Diagnosis: Yes

Expected Result: High Risk (Red Orb)
```

---

## 🎨 Visual Features to Notice

### Animations
- ✨ Splash screen orb pulsing
- ✨ Floating health icons
- ✨ Onboarding slide transitions
- ✨ Progress bar growth
- ✨ Analysis loading animation
- ✨ 3D orb rotation
- ✨ Glow pulse effects
- ✨ Button hover scale
- ✨ Card lift on hover

### Design Elements
- 🎨 Gradient shifting background
- 🎨 Glassmorphism effects
- 🎨 Soft shadows
- 🎨 Rounded corners everywhere
- 🎨 Pastel color palette
- 🎨 Large readable fonts
- 🎨 Emoji icons in food cards

### Interactions
- 👆 Tap buttons for micro-animations
- 👆 Hover over cards to see lift
- 👆 Drag fatigue slider
- 👆 Watch progress bar animate
- 👆 See checkmarks appear in analysis

---

## 🔍 Keyboard Navigation

For accessibility testing:
- `Tab` - Navigate between elements
- `Space` - Select checkboxes/radio buttons
- `Enter` - Submit forms, click buttons
- `Arrow Keys` - Navigate radio button groups

---

## 🐛 Troubleshooting

### Issue: Splash screen doesn't auto-advance
**Solution**: Wait 3 seconds or refresh the page

### Issue: Questionnaire won't proceed
**Solution**: Make sure you've answered the current question (radio button or checkbox selected)

### Issue: Animations not smooth
**Solution**: 
- Use a modern browser (Chrome, Firefox, Safari, Edge)
- Close other tabs to free up resources
- Update your browser to the latest version

### Issue: Mobile view looks wrong
**Solution**: 
- Ensure viewport meta tag is present (it is!)
- Try refreshing the page
- Check browser zoom level (should be 100%)

### Issue: Data not saving
**Solution**: 
- Check localStorage is enabled in browser settings
- Don't use incognito/private mode (localStorage is cleared)

---

## 📊 Browser Compatibility

### Fully Supported ✅
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Opera 76+

### Partially Supported ⚠️
- Safari 12-13 (some CSS features degraded)
- Older mobile browsers

### Not Supported ❌
- Internet Explorer (any version)
- Very old mobile browsers

---

## 💡 Pro Tips

1. **Best Experience**: Use Chrome on desktop with DevTools mobile emulation
2. **Mobile Testing**: Use iPhone 12 Pro or Pixel 5 preset in DevTools
3. **Screenshot**: Take screenshots at risk result screen - looks amazing!
4. **Demo**: Always start from splash screen for full impact
5. **Privacy Banner**: Click "Got it" to dismiss the bottom banner

---

## 📸 Screenshot Opportunities

### Must-Capture Screens:
1. Splash screen with animated orb
2. Onboarding slide 3 (AI-Powered Assessment)
3. Questionnaire Step 2 (slider with colorful bar)
4. AI Analysis screen (all steps checked)
5. Risk Result screen (3D orb in any color)
6. Recommendations food grid
7. Education Hub cards
8. Emergency Support screen

---

## 🎤 Demo Presentation Tips

### Opening (30 seconds)
> "30% of women worldwide suffer from anemia. Many don't know they're at risk. Meet SheCare AI - an empathetic, accessible app that brings anemia screening to every woman's fingertips."

### Feature Demo (2 minutes)
1. Show onboarding flow (skip quickly)
2. Fill profile rapidly
3. Navigate questionnaire highlighting smart UX
4. Let analysis animation play fully
5. Show risk result with confidence meter
6. Quickly show recommendations

### Impact Discussion (1 minute)
> "This works offline, respects privacy, supports multiple languages, and costs nothing. It's ready for deployment in rural health centers, schools, and NGO programs across India."

### Closing (30 seconds)
> "SheCare AI doesn't diagnose - it educates and empowers. It's the first step in a journey toward better women's health, accessible to all."

---

## 🚀 Next Steps After Testing

1. ✅ Test all features thoroughly
2. ✅ Note any bugs or improvements
3. ✅ Test on multiple devices
4. ✅ Share feedback
5. ✅ Consider contributing enhancements

---

## 📞 Quick Reference

**Emergency Helplines (India):**
- National Emergency: **108**
- Women's Helpline: **1091**

**Medical Disclaimer:**
This is NOT a medical diagnostic tool. Always consult healthcare professionals.

---

## 🎉 Enjoy Exploring SheCare AI!

**Remember**: Every feature was designed with love, empathy, and a commitment to women's health empowerment.

**Built with ❤️ for women's health**

---

**Questions?** Check the main README.md for detailed documentation.

**Ready to Deploy?** See the DEPLOYMENT.md guide (coming soon).

**Want to Contribute?** Fork the repo and submit a PR!
